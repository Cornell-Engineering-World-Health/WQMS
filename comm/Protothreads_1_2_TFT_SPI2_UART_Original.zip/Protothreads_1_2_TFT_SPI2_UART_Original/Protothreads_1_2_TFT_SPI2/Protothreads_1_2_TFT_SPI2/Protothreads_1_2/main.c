/**
 * This is a very small example that shows how to use
 * === OUTPUT COMPARE  ===
/*
 * File:        PWM example
 * Author:      Bruce Land
 * Target PIC:  PIC32MX250F128B
 */

////////////////////////////////////
// clock AND protoThreads configure!
// You MUST check this file!
#include "config.h"
// threading library
#include "pt_cornell_1_2.h"
// graphics libraries
#include "tft_master.h"
#include "tft_gfx.h"
#include <stdio.h>
#define Digipot_config_chan_A 0b0000000000000000


// === thread structures ============================================
// thread control structs

//print lock
static struct pt_sem print_sem;

// note that UART input and output are threads
static struct pt pt_cmd, pt_time, pt_input, pt_output, pt_DMA_output, pt_pid;

// system 1 second interval tick
int sys_time_seconds;

//The actual period of the wave
int generate_period = 40000; //generated to handle 50 Hz cutoff frequency with 1:16 prescalar
int pwm_on_time = 500;
//print state variable
int printing = 0;
// system 1 second interval tick
int sys_time_seconds;
// string buffer
char buffer[10000];
//Input capture period
short volatile lastcapture = 0, capture1 = 0;
volatile float period;
volatile float rpm; //used in isr
volatile int previousrpm;
static float input_rpm;
static float p, i, d, c;
static float pid_integral = 0;
static float error;
static float previous_error = 0;
static float scaledpid;
static float scaledrpm;
volatile SpiChannel spiChn = SPI_CHANNEL1;
volatile int spiClkDiv = 4; //run spi at 10 MH

// === Command Thread ======================================================
// The serial interface
static char cmd[16];
static int value;
static char placeholderinput[20] = "{placeholder input}"; // this would actually be the JSON recieved from DAQ team


static PT_THREAD(protothread_cmd(struct pt *pt)) {
    PT_BEGIN(pt);
    while (1) {
        PT_YIELD(pt);
       
        sprintf(PT_send_buffer, "\r\r\rAT\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
        
        sprintf(PT_send_buffer, "AT+COPS?\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
        
        sprintf(PT_send_buffer, "AT+CSQ\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(1000);
        
        //SENDING TEXT
        /*sprintf(PT_send_buffer, "AT+CMGF=1\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        sprintf(PT_send_buffer, "AT+CMGS=\"2403287871\"\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        sprintf(PT_send_buffer, "Let this text please work\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        sprintf(PT_send_buffer, "^Z\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);*/
        
        sprintf(PT_send_buffer, "AT+SAPBR=2,1\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(6000);
        
        sprintf(PT_send_buffer, "AT+SAPBR=1,1\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(6000);
        
        sprintf(PT_send_buffer, "AT+HTTPINIT\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        
        
        
        sprintf(PT_send_buffer, "AT+HTTPPARA=\"CID\",1\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
      /*  
        sprintf(PT_send_buffer, "AT+HTTPPARA=\"URL\",\"http://ec2-54-86-133-189.compute-1.amazonaws.com:8080/api/data/WaterQuality\"\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        sprintf(PT_send_buffer, "AT+HTTPACTION=0\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        sprintf(PT_send_buffer, "AT+HTTPREAD\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);*/
        
        sprintf(PT_send_buffer, "AT+HTTPPARA= \"URL\", \"http://requestb.in/1ekctoc1\"\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
        
        sprintf(PT_send_buffer, "AT+HTTPPARA=\"CONTENT\",\"application/json\"\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
        
        sprintf(PT_send_buffer,"AT+HTTPDATA=10000,10000\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output) );
        PT_YIELD_TIME_msec(500);
        
        sprintf(PT_send_buffer,"data=[{\"temperature\": 78,\"turbidity\": 4,\"conductivity\": 7,\"sodium\": 2,\"magnesium\": 3,\"calcium\": 2,\"pH\": 8,\"timestamp\": \"2016-11-11T12:00:00Z\",\"usage\": 23 }]");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output) );
        PT_YIELD_TIME_msec(11000);
        
        sprintf(PT_send_buffer, "AT+HTTPACTION=1\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(500);
      
   
      
        //in here we want to check if placeholderinput = AT+HTTPREAD's output but im not sure how we would do that. 
        
        sprintf(PT_send_buffer, "AT+HTTPTERM\r");
        PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output));
        PT_YIELD_TIME_msec(2000);
        
        
        
        
        PT_SPAWN(pt, &pt_input, PT_GetSerialBuffer(&pt_input));
        
        sscanf(PT_term_buffer, "%s %d", cmd, &value);

        if (cmd[0] == 'p') {
            p = value;
            /*// update the timer period
            WritePeriod2(generate_period);
            // update the pulse start/stop
            SetPulseOC2(generate_period>>2, generate_period>>1);*/
        }

        if (cmd[0] == 'd') {
            d = value;
            //SetDCOC3PWM(pwm_on_time);
        } //  

        if (cmd[0] == 'i') {
            i = value;
            // by spawning a print thread
            //PT_SPAWN(pt, &pt_DMA_output, PT_DMA_PutSerialBuffer(&pt_DMA_output) );
        } //  

        if (cmd[0] == 's') {
            input_rpm = value;
            //SetDCOC3PWM(pwm_on_time);
        } //  

        if (cmd[0] == 'd') {
            //set mux to DSP chip
            mPORTAClearBits(BIT_4);
            mPORTBClearBits(BIT_13);
            mPORTASetBits(BIT_4);
            mPORTBClearBits(BIT_3 | BIT_7 | BIT_8 | BIT_9);

            if (((value << 6) & (0x0040))) {
                mPORTBSetBits(BIT_3);
            }
            //select sound effect
            mPORTBSetBits(value << 6);
        }
        if (cmd[0] == 's') { //distortion
            //set mux to Distortion
            mPORTAClearBits(BIT_4);
            mPORTBClearBits(BIT_13);
        }
        if (cmd[0] == 'n') { //normal: only tone stack
            //set mux to channel 0
            mPORTAClearBits(BIT_4);
            mPORTBClearBits(BIT_13);
            mPORTBSetBits(BIT_13);
        }
        //pots
        if (cmd[0] == 't') { //treble
            // CS low to start transaction
            mPORTBClearBits(BIT_4); // start transaction
            deliverSPICh1Datum(value);
            // CS high
            mPORTBSetBits(BIT_4); // end transaction
        }
        if (cmd[0] == 'b') { //bass
            // CS low to start transaction
            mPORTAClearBits(BIT_0); // start transaction
            deliverSPICh1Datum(value);
            // CS high
            mPORTASetBits(BIT_0); // end transaction
        }
        if (cmd[0] == 'v') { //level
            // CS low to start transaction
            mPORTAClearBits(BIT_2); // start transaction
            deliverSPICh1Datum(value);
            // CS high
            mPORTASetBits(BIT_2); // end transaction
        }
        if (cmd[0] == 'm') { //mid
            // CS low to start transaction
            mPORTAClearBits(BIT_3); // start transaction
            deliverSPICh1Datum(value);
            // CS high
            mPORTASetBits(BIT_3); // end transaction
        }
        // never exit while
    } // END WHILE(1)
    PT_END(pt);
} // thread 3


 /*char stringBuilder(char input[]){
     char output[10000];
     
     for (i = 1; input[i]; i++){
         
     }
}*/
void deliverSPICh1Datum(int datum) {
    // test for ready
    while (TxBufFullSPI1());
    // write to spi2
    WriteSPI1(Digipot_config_chan_A | datum);
    // test for done
    while (SPI1STATbits.SPIBUSY); // wait for end of transaction
    // CS high
    // mPORTBSetBits(BIT_4); // end transaction
}

// === One second Thread ======================================================
// update a 1 second tick counter

static PT_THREAD(protothread_time(struct pt *pt)) {
    PT_BEGIN(pt);

    while (1) {
        // yield time 1 second
        PT_YIELD_TIME_msec(200);
        //sys_time_seconds++ ;
        tft_fillRoundRect(20, 10, 200, 14, 1, ILI9340_BLACK); // x,y,w,h,radius,color
        tft_setCursor(20, 10);
        tft_setTextColor(ILI9340_YELLOW);
        tft_setTextSize(2);
        sprintf(buffer, "%f  %f", rpm, scaledpid);
        tft_writeString(buffer);
        // NEVER exit while
    } // END WHILE(1)

    PT_END(pt);
} // thread 4

static PT_THREAD(protothread_pid(struct pt *pt)) {
    /*   %sensor update
    % integrate to get new shaft position
    sensor_pos(i) = sensor_pos(i-1) + dt * m_output(i-1) ;
    % if one full rotation has occured, then update sensor
    % otherwise extrapolate from last measurements
    if fix(sensor_pos(i)) > fix(sensor_pos(i-1))
      raw_sensor = m_output(i-1) ;
      sensor_output(i) = raw_sensor ;
    else
      sensor_output(i) = raw_sensor ;
    end
   
    % control error
    c_error(i) = c_input(i) - sensor_output(i) ;
   
    % PID algorithm for a system with NO negative output
    % get integral error term
    if sign(c_error(i)) == sign(c_error(i-1))
        pid_integral = pid_integral + c_error(i) ;
    else
        pid_integral = 0;
    end
   
    % sum the PID terms,  zero neg output, and limit max
    m_input(i) = ...
            A * c_error(i) + ...
            B * pid_integral  + ...
            C * (c_error(i)-c_error(i-1))  ;
    m_input(i) = min(m_input(i) * (m_input(i)>0), m_max) ;*/
    PT_BEGIN(pt);
    while (1) {
        PT_YIELD_TIME_msec(10);
        //control error
        previousrpm = rpm;
        rpm = (1.0 / (float) period)*(156250.0 * 60.0 / 7.0); // rev/tick * ticks/sec, divided by 7 because seven blades on fan
        if ((previousrpm - rpm > 100) || (rpm - previousrpm > 300)) {
            rpm = previousrpm;
        }
        previous_error = error;
        error = input_rpm - rpm;


        if (((error < 0) && (previous_error < 0)) || ((error >= 0) && (previous_error >= 0))) {
            pid_integral = pid_integral + error;
        } else {
            pid_integral = 0;
            //pid_integral =  .9*pid_integral;
        }
        if (error >= 0) {
            c = p * error + i * pid_integral + d * (error - previous_error);
        } else {
            c = 0;
            // pid_integral = 0;
        }
        //scaledpid = (c/2940.0)*40000.0; //scale c to 1kHz where 3000 is range of c
        scaledrpm = (rpm / 3000.0)*40000.0; //scale rpm to 3000 revs/minute
        if (scaledpid > 40000) {
            SetDCOC3PWM(40000);
        } else {
            SetDCOC3PWM(c);
        }

        if (scaledrpm > 40000) {
            SetDCOC2PWM(40000);
        } else {
            SetDCOC2PWM(scaledrpm);
        }

    }
    PT_END(pt);
}

__ISR(_INPUT_CAPTURE_1_VECTOR, ipl3) inputCaptureISR(void) {
    //capture ic value - store in global
    capture1 = mIC1ReadCapture(); //gets current timer value
    period = capture1 - lastcapture;
    lastcapture = capture1;

    //clear interrupt/timer flag for input capture
    mIC1ClearIntFlag();
    //reset timer 3

}

// === Main  ======================================================

int main(void) {


    // === init the USART i/o pins =========
    PPSInput(2, U2RX, RPB11); //Assign U2RX to pin RPB11 -- Physical pin 22 on 28 PDIP
    PPSOutput(4, RPB10, U2TX); //Assign U2TX to pin RPB10 -- Physical pin 21 on 28 PDIP

    ANSELA = 0; //make sure analog is cleared
    ANSELB = 0;

    // === init the uart2 ===================
    UARTConfigure(UART2, UART_ENABLE_PINS_TX_RX_ONLY);
    UARTSetLineControl(UART2, UART_DATA_SIZE_8_BITS | UART_PARITY_NONE | UART_STOP_BITS_1);
    UARTSetDataRate(UART2, PB_FREQ, BAUDRATE);
    UARTEnable(UART2, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));
    printf("protothreads start..\n\r");

    // === Config timer and output compares to make pulses ========
    // set up timer2 to generate the wave period
    OpenTimer3(T3_ON | T3_SOURCE_INT | T3_PS_1_1, generate_period);

    // set up compare3 for PWM mode
    OpenOC3(OC_ON | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE, pwm_on_time, pwm_on_time); //
    // OC3 is PPS group 4, map to RPB9 (pin 18)
    PPSOutput(4, RPB9, OC3);

    // set up compare3 for PWM mode
    OpenOC2(OC_ON | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE, pwm_on_time, pwm_on_time); //
    // OC3 is PPS group 4, map to RPB9 (pin 18)
    PPSOutput(2, RPB8, OC2);
    //setup timer 3 as ic source
    // === Config timer3 free running ==========================
    // set up timer3 as a souce for input capture
    // and let it overflow for contunuous readings
    OpenTimer2(T2_ON | T2_SOURCE_INT | T2_PS_1_256, 0xffff); //overflow timer at 0xffff

    // connect PIN 24 to IC1 capture unit
    mPORTBSetPinsDigitalIn(BIT_13); //Set port as input
    PPSInput(3, IC1, RPB13); //tie ic1 to rpb13

    //input capture setup
    // === set up input capture ================================
    OpenCapture1(IC_EVERY_RISE_EDGE | IC_INT_1CAPTURE | IC_TIMER2_SRC | IC_ON);
    // turn on the interrupt so that every capture can be recorded
    ConfigIntCapture1(IC_INT_ON | IC_INT_PRIOR_3 | IC_INT_SUB_PRIOR_3);
    INTClearFlag(INT_IC1);

    // === config the uart, DMA, vref, timer5 ISR ===========
    PT_setup();

    // init the display
    tft_init_hw();
    tft_begin();
    tft_fillScreen(ILI9340_BLACK);
    //240x320 vertical display
    tft_setRotation(0); // Use tft_setRotation(1) for 320x240
    tft_fillRoundRect(0, 10, 100, 14, 1, ILI9340_BLACK); // x,y,w,h,radius,color
    tft_setCursor(0, 10);
    tft_setTextColor(ILI9340_YELLOW);
    tft_setTextSize(2);
    // === setup system wide interrupts  ====================
    INTEnableSystemMultiVectoredInt();

    // === set up i/o port pin ===============================
    mPORTBSetPinsDigitalOut(BIT_0); //Set port as output

    // === now the threads ===================================

    // init the threads
    PT_INIT(&pt_cmd);
    PT_INIT(&pt_time);
    PT_INIT(&pt_pid);

    // schedule the threads
    while (1) {
        PT_SCHEDULE(protothread_cmd(&pt_cmd));
        PT_SCHEDULE(protothread_time(&pt_time));
        PT_SCHEDULE(protothread_pid(&pt_pid));
    }
} // main